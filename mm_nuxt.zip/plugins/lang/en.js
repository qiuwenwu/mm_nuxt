export default {
  // 左边栏
  root: {
    btn_connect: "Connect",
    btn_nft: "NFT",
    btn_pool: "Pool",
    btn_auction: "Auction",
    btn_ranking: "Ranking",
    btn_statis: "Statis",
    btn_bag: "Bag",
    btn_update: "Update",
    btn_invite: "Invite"
  },
  nft: {

  },
  pool: {

  },
  auction: {

  },
  ranking: {

  },
  statis: {

  },
  bag: {
    title: "背包",
    title_balance: "余额",
    btn_exchange: "交易",
    btn_auction: "拍卖"
  },
  update: {

  },
  invite: {

  }
}
