export default {
  // 左边栏
  root: {
    btn_connect: "连接",
    btn_nft: "盲合",
    btn_pool: "矿池",
    btn_auction: "拍卖",
    btn_ranking: "排名",
    btn_statis: "统计",
    btn_bag: "背包",
    btn_update: "升级",
    btn_invite: "邀请"
  },
  nft: {

  },
  pool: {

  },
  auction: {

  },
  ranking: {

  },
  statis: {

  },
  bag: {
    title: "背包",
    title_balance: "余额",
    btn_exchange: "交易",
    btn_auction: "拍卖"
  },
  update: {

  },
  invite: {

  }
}
