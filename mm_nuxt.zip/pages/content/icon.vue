<template>
	<mm_page id="page_icon">
		<header class="header">
			<mm_warp>
				<mm_container>
					<mm_row>
						<mm_col width="100">
							<mm_view url="/">
								<h3>
									<span>图标</span>
									<span class="fr">&lt; 返回</span>
								</h3>
							</mm_view>
						</mm_col>
					</mm_row>
				</mm_container>
			</mm_warp>
		</header>
		<main>
			<mm_warp>
				<mm_container>
					<mm_row>
						<mm_col class="col-md-6">
							<mm_card>
								<div class="card_head">字体图标</div>
								<div class="card_body">
									<mm_icon src="<i class='fa fa-user'></i>"></mm_icon>
									<div class="icons">
										<ul>
											<li>
												<span class="fa-asterisk"></span>
												<span>fa-asterisk</span>
											</li>
									
											<li>
												<span class="fa-plus"></span>
												<span>fa-plus</span>
											</li>
									
											<li>
												<span class="fa-euro"></span>
												<span>fa-euro</span>
											</li>
									
											<li>
												<span class="fa-eur"></span>
												<span>fa-eur</span>
											</li>
									
											<li>
												<span class="fa-minus"></span>
												<span>fa-minus</span>
											</li>
									
											<li>
												<span class="fa-cloud"></span>
												<span>fa-cloud</span>
											</li>
									
											<li>
												<span class="fa-envelope"></span>
												<span>fa-envelope</span>
											</li>
									
											<li>
												<span class="fa-pencil"></span>
												<span>fa-pencil</span>
											</li>
									
											<li>
												<span class="fa-glass"></span>
												<span>fa-glass</span>
											</li>
									
											<li>
												<span class="fa-music"></span>
												<span>fa-music</span>
											</li>
									
											<li>
												<span class="fa-search"></span>
												<span>fa-search</span>
											</li>
									
											<li>
												<span class="fa-heart"></span>
												<span>fa-heart</span>
											</li>
									
											<li>
												<span class="fa-star"></span>
												<span>fa-star</span>
											</li>
									
											<li>
												<span class="fa-star-empty"></span>
												<span>fa-star-empty</span>
											</li>
									
											<li>
												<span class="fa-user"></span>
												<span>fa-user</span>
											</li>
									
											<li>
												<span class="fa-film"></span>
												<span>fa-film</span>
											</li>
									
											<li>
												<span class="fa-th-large"></span>
												<span>fa-th-large</span>
											</li>
									
											<li>
												<span class="fa-th"></span>
												<span>fa-th</span>
											</li>
									
											<li>
												<span class="fa-th-list"></span>
												<span>fa-th-list</span>
											</li>
									
											<li>
												<span class="fa-ok"></span>
												<span>fa-ok</span>
											</li>
									
											<li>
												<span class="fa-remove"></span>
												<span>fa-remove</span>
											</li>
									
											<li>
												<span class="fa-zoom-in"></span>
												<span>fa-zoom-in</span>
											</li>
									
											<li>
												<span class="fa-zoom-out"></span>
												<span>fa-zoom-out</span>
											</li>
									
											<li>
												<span class="fa-off"></span>
												<span>fa-off</span>
											</li>
									
											<li>
												<span class="fa-signal"></span>
												<span>fa-signal</span>
											</li>
									
											<li>
												<span class="fa-cog"></span>
												<span>fa-cog</span>
											</li>
									
											<li>
												<span class="fa-trash"></span>
												<span>fa-trash</span>
											</li>
									
											<li>
												<span class="fa-home"></span>
												<span>fa-home</span>
											</li>
									
											<li>
												<span class="fa-file"></span>
												<span>fa-file</span>
											</li>
									
											<li>
												<span class="fa-time"></span>
												<span>fa-time</span>
											</li>
									
											<li>
												<span class="fa-road"></span>
												<span>fa-road</span>
											</li>
									
											<li>
												<span class="fa-download-alt"></span>
												<span>fa-download-alt</span>
											</li>
									
											<li>
												<span class="fa-download"></span>
												<span>fa-download</span>
											</li>
									
											<li>
												<span class="fa-upload"></span>
												<span>fa-upload</span>
											</li>
									
											<li>
												<span class="fa-inbox"></span>
												<span>fa-inbox</span>
											</li>
									
											<li>
												<span class="fa-play-circle"></span>
												<span>fa-play-circle</span>
											</li>
									
											<li>
												<span class="fa-repeat"></span>
												<span>fa-repeat</span>
											</li>
									
											<li>
												<span class="fa-refresh"></span>
												<span>fa-refresh</span>
											</li>
									
											<li>
												<span class="fa-list-alt"></span>
												<span>fa-list-alt</span>
											</li>
									
											<li>
												<span class="fa-lock"></span>
												<span>fa-lock</span>
											</li>
									
											<li>
												<span class="fa-flag"></span>
												<span>fa-flag</span>
											</li>
									
											<li>
												<span class="fa-headphones"></span>
												<span>fa-headphones</span>
											</li>
									
											<li>
												<span class="fa-volume-off"></span>
												<span>fa-volume-off</span>
											</li>
									
											<li>
												<span class="fa-volume-down"></span>
												<span>fa-volume-down</span>
											</li>
									
											<li>
												<span class="fa-volume-up"></span>
												<span>fa-volume-up</span>
											</li>
									
											<li>
												<span class="fa-qrcode"></span>
												<span>fa-qrcode</span>
											</li>
									
											<li>
												<span class="fa-barcode"></span>
												<span>fa-barcode</span>
											</li>
									
											<li>
												<span class="fa-tag"></span>
												<span>fa-tag</span>
											</li>
									
											<li>
												<span class="fa-tags"></span>
												<span>fa-tags</span>
											</li>
									
											<li>
												<span class="fa-book"></span>
												<span>fa-book</span>
											</li>
									
											<li>
												<span class="fa-bookmark"></span>
												<span>fa-bookmark</span>
											</li>
									
											<li>
												<span class="fa-print"></span>
												<span>fa-print</span>
											</li>
									
											<li>
												<span class="fa-camera"></span>
												<span>fa-camera</span>
											</li>
									
											<li>
												<span class="fa-font"></span>
												<span>fa-font</span>
											</li>
									
											<li>
												<span class="fa-bold"></span>
												<span>fa-bold</span>
											</li>
									
											<li>
												<span class="fa-italic"></span>
												<span>fa-italic</span>
											</li>
									
											<li>
												<span class="fa-text-height"></span>
												<span>fa-text-height</span>
											</li>
									
											<li>
												<span class="fa-text-width"></span>
												<span>fa-text-width</span>
											</li>
									
											<li>
												<span class="fa-align-left"></span>
												<span>fa-align-left</span>
											</li>
									
											<li>
												<span class="fa-align-center"></span>
												<span>fa-align-center</span>
											</li>
									
											<li>
												<span class="fa-align-right"></span>
												<span>fa-align-right</span>
											</li>
									
											<li>
												<span class="fa-align-justify"></span>
												<span>fa-align-justify</span>
											</li>
									
											<li>
												<span class="fa-list"></span>
												<span>fa-list</span>
											</li>
									
											<li>
												<span class="fa-indent-left"></span>
												<span>fa-indent-left</span>
											</li>
									
											<li>
												<span class="fa-indent-right"></span>
												<span>fa-indent-right</span>
											</li>
									
											<li>
												<span class="fa-facetime-video"></span>
												<span>fa-facetime-video</span>
											</li>
									
											<li>
												<span class="fa-picture"></span>
												<span>fa-picture</span>
											</li>
									
											<li>
												<span class="fa-map-marker"></span>
												<span>fa-map-marker</span>
											</li>
									
											<li>
												<span class="fa-adjust"></span>
												<span>fa-adjust</span>
											</li>
									
											<li>
												<span class="fa-tint"></span>
												<span>fa-tint</span>
											</li>
									
											<li>
												<span class="fa-edit"></span>
												<span>fa-edit</span>
											</li>
									
											<li>
												<span class="fa-share"></span>
												<span>fa-share</span>
											</li>
									
											<li>
												<span class="fa-check"></span>
												<span>fa-check</span>
											</li>
									
											<li>
												<span class="fa-move"></span>
												<span>fa-move</span>
											</li>
									
											<li>
												<span class="fa-step-backward"></span>
												<span>fa-step-backward</span>
											</li>
									
											<li>
												<span class="fa-fast-backward"></span>
												<span>fa-fast-backward</span>
											</li>
									
											<li>
												<span class="fa-backward"></span>
												<span>fa-backward</span>
											</li>
									
											<li>
												<span class="fa-play"></span>
												<span>fa-play</span>
											</li>
									
											<li>
												<span class="fa-pause"></span>
												<span>fa-pause</span>
											</li>
									
											<li>
												<span class="fa-stop"></span>
												<span>fa-stop</span>
											</li>
									
											<li>
												<span class="fa-forward"></span>
												<span>fa-forward</span>
											</li>
									
											<li>
												<span class="fa-fast-forward"></span>
												<span>fa-fast-forward</span>
											</li>
									
											<li>
												<span class="fa-step-forward"></span>
												<span>fa-step-forward</span>
											</li>
									
											<li>
												<span class="fa-eject"></span>
												<span>fa-eject</span>
											</li>
									
											<li>
												<span class="fa-chevron-left"></span>
												<span>fa-chevron-left</span>
											</li>
									
											<li>
												<span class="fa-chevron-right"></span>
												<span>fa-chevron-right</span>
											</li>
									
											<li>
												<span class="fa-plus-sign"></span>
												<span>fa-plus-sign</span>
											</li>
									
											<li>
												<span class="fa-minus-sign"></span>
												<span>fa-minus-sign</span>
											</li>
									
											<li>
												<span class="fa-remove-sign"></span>
												<span>fa-remove-sign</span>
											</li>
									
											<li>
												<span class="fa-ok-sign"></span>
												<span>fa-ok-sign</span>
											</li>
									
											<li>
												<span class="fa-question-sign"></span>
												<span>fa-question-sign</span>
											</li>
									
											<li>
												<span class="fa-info-sign"></span>
												<span>fa-info-sign</span>
											</li>
									
											<li>
												<span class="fa-screenshot"></span>
												<span>fa-screenshot</span>
											</li>
									
											<li>
												<span class="fa-remove-circle"></span>
												<span>fa-remove-circle</span>
											</li>
									
											<li>
												<span class="fa-ok-circle"></span>
												<span>fa-ok-circle</span>
											</li>
									
											<li>
												<span class="fa-ban-circle"></span>
												<span>fa-ban-circle</span>
											</li>
									
											<li>
												<span class="fa-arrow-left"></span>
												<span>fa-arrow-left</span>
											</li>
									
											<li>
												<span class="fa-arrow-right"></span>
												<span>fa-arrow-right</span>
											</li>
									
											<li>
												<span class="fa-arrow-up"></span>
												<span>fa-arrow-up</span>
											</li>
									
											<li>
												<span class="fa-arrow-down"></span>
												<span>fa-arrow-down</span>
											</li>
									
											<li>
												<span class="fa-share-alt"></span>
												<span>fa-share-alt</span>
											</li>
									
											<li>
												<span class="fa-resize-full"></span>
												<span>fa-resize-full</span>
											</li>
									
											<li>
												<span class="fa-resize-small"></span>
												<span>fa-resize-small</span>
											</li>
									
											<li>
												<span class="fa-exclamation-sign"></span>
												<span>fa-exclamation-sign</span>
											</li>
									
											<li>
												<span class="fa-gift"></span>
												<span>fa-gift</span>
											</li>
									
											<li>
												<span class="fa-leaf"></span>
												<span>fa-leaf</span>
											</li>
									
											<li>
												<span class="fa-fire"></span>
												<span>fa-fire</span>
											</li>
									
											<li>
												<span class="fa-eye-open"></span>
												<span>fa-eye-open</span>
											</li>
									
											<li>
												<span class="fa-eye-close"></span>
												<span>fa-eye-close</span>
											</li>
									
											<li>
												<span class="fa-warning-sign"></span>
												<span>fa-warning-sign</span>
											</li>
									
											<li>
												<span class="fa-plane"></span>
												<span>fa-plane</span>
											</li>
									
											<li>
												<span class="fa-calendar"></span>
												<span>fa-calendar</span>
											</li>
									
											<li>
												<span class="fa-random"></span>
												<span>fa-random</span>
											</li>
									
											<li>
												<span class="fa-comment"></span>
												<span>fa-comment</span>
											</li>
									
											<li>
												<span class="fa-magnet"></span>
												<span>fa-magnet</span>
											</li>
									
											<li>
												<span class="fa-chevron-up"></span>
												<span>fa-chevron-up</span>
											</li>
									
											<li>
												<span class="fa-chevron-down"></span>
												<span>fa-chevron-down</span>
											</li>
									
											<li>
												<span class="fa-retweet"></span>
												<span>fa-retweet</span>
											</li>
									
											<li>
												<span class="fa-shopping-cart"></span>
												<span>fa-shopping-cart</span>
											</li>
									
											<li>
												<span class="fa-folder-close"></span>
												<span>fa-folder-close</span>
											</li>
									
											<li>
												<span class="fa-folder-open"></span>
												<span>fa-folder-open</span>
											</li>
									
											<li>
												<span class="fa-resize-vertical"></span>
												<span>fa-resize-vertical</span>
											</li>
									
											<li>
												<span class="fa-resize-horizontal"></span>
												<span>fa-resize-horizontal</span>
											</li>
									
											<li>
												<span class="fa-hdd"></span>
												<span>fa-hdd</span>
											</li>
									
											<li>
												<span class="fa-bullhorn"></span>
												<span>fa-bullhorn</span>
											</li>
									
											<li>
												<span class="fa-bell"></span>
												<span>fa-bell</span>
											</li>
									
											<li>
												<span class="fa-certificate"></span>
												<span>fa-certificate</span>
											</li>
									
											<li>
												<span class="fa-thumbs-up"></span>
												<span>fa-thumbs-up</span>
											</li>
									
											<li>
												<span class="fa-thumbs-down"></span>
												<span>fa-thumbs-down</span>
											</li>
									
											<li>
												<span class="fa-hand-right"></span>
												<span>fa-hand-right</span>
											</li>
									
											<li>
												<span class="fa-hand-left"></span>
												<span>fa-hand-left</span>
											</li>
									
											<li>
												<span class="fa-hand-up"></span>
												<span>fa-hand-up</span>
											</li>
									
											<li>
												<span class="fa-hand-down"></span>
												<span>fa-hand-down</span>
											</li>
									
											<li>
												<span class="fa-circle-arrow-right"></span>
												<span>fa-circle-arrow-right</span>
											</li>
									
											<li>
												<span class="fa-circle-arrow-left"></span>
												<span>fa-circle-arrow-left</span>
											</li>
									
											<li>
												<span class="fa-circle-arrow-up"></span>
												<span>fa-circle-arrow-up</span>
											</li>
									
											<li>
												<span class="fa-circle-arrow-down"></span>
												<span>fa-circle-arrow-down</span>
											</li>
									
											<li>
												<span class="fa-globe"></span>
												<span>fa-globe</span>
											</li>
									
											<li>
												<span class="fa-wrench"></span>
												<span>fa-wrench</span>
											</li>
									
											<li>
												<span class="fa-tasks"></span>
												<span>fa-tasks</span>
											</li>
									
											<li>
												<span class="fa-filter"></span>
												<span>fa-filter</span>
											</li>
									
											<li>
												<span class="fa-briefcase"></span>
												<span>fa-briefcase</span>
											</li>
									
											<li>
												<span class="fa-fullscreen"></span>
												<span>fa-fullscreen</span>
											</li>
									
											<li>
												<span class="fa-dashboard"></span>
												<span>fa-dashboard</span>
											</li>
									
											<li>
												<span class="fa-paperclip"></span>
												<span>fa-paperclip</span>
											</li>
									
											<li>
												<span class="fa-heart-empty"></span>
												<span>fa-heart-empty</span>
											</li>
									
											<li>
												<span class="fa-link"></span>
												<span>fa-link</span>
											</li>
									
											<li>
												<span class="fa-phone"></span>
												<span>fa-phone</span>
											</li>
									
											<li>
												<span class="fa-pushpin"></span>
												<span>fa-pushpin</span>
											</li>
									
											<li>
												<span class="fa-usd"></span>
												<span>fa-usd</span>
											</li>
									
											<li>
												<span class="fa-gbp"></span>
												<span>fa-gbp</span>
											</li>
									
											<li>
												<span class="fa-sort"></span>
												<span>fa-sort</span>
											</li>
									
											<li>
												<span class="fa-sort-by-alphabet"></span>
												<span>fa-sort-by-alphabet</span>
											</li>
									
											<li>
												<span class="fa-sort-by-alphabet-alt"></span>
												<span>fa-sort-by-alphabet-alt</span>
											</li>
									
											<li>
												<span class="fa-sort-by-order"></span>
												<span>fa-sort-by-order</span>
											</li>
									
											<li>
												<span class="fa-sort-by-order-alt"></span>
												<span>fa-sort-by-order-alt</span>
											</li>
									
											<li>
												<span class="fa-sort-by-attributes"></span>
												<span>fa-sort-by-attributes</span>
											</li>
									
											<li>
												<span class="fa-sort-by-attributes-alt"></span>
												<span>fa-sort-by-attributes-alt</span>
											</li>
									
											<li>
												<span class="fa-unchecked"></span>
												<span>fa-unchecked</span>
											</li>
									
											<li>
												<span class="fa-expand"></span>
												<span>fa-expand</span>
											</li>
									
											<li>
												<span class="fa-collapse-down"></span>
												<span>fa-collapse-down</span>
											</li>
									
											<li>
												<span class="fa-collapse-up"></span>
												<span>fa-collapse-up</span>
											</li>
									
											<li>
												<span class="fa-log-in"></span>
												<span>fa-log-in</span>
											</li>
									
											<li>
												<span class="fa-flash"></span>
												<span>fa-flash</span>
											</li>
									
											<li>
												<span class="fa-log-out"></span>
												<span>fa-log-out</span>
											</li>
									
											<li>
												<span class="fa-new-window"></span>
												<span>fa-new-window</span>
											</li>
									
											<li>
												<span class="fa-record"></span>
												<span>fa-record</span>
											</li>
									
											<li>
												<span class="fa-save"></span>
												<span>fa-save</span>
											</li>
									
											<li>
												<span class="fa-open"></span>
												<span>fa-open</span>
											</li>
									
											<li>
												<span class="fa-saved"></span>
												<span>fa-saved</span>
											</li>
									
											<li>
												<span class="fa-import"></span>
												<span>fa-import</span>
											</li>
									
											<li>
												<span class="fa-export"></span>
												<span>fa-export</span>
											</li>
									
											<li>
												<span class="fa-send"></span>
												<span>fa-send</span>
											</li>
									
											<li>
												<span class="fa-floppy-disk"></span>
												<span>fa-floppy-disk</span>
											</li>
									
											<li>
												<span class="fa-floppy-saved"></span>
												<span>fa-floppy-saved</span>
											</li>
									
											<li>
												<span class="fa-floppy-remove"></span>
												<span>fa-floppy-remove</span>
											</li>
									
											<li>
												<span class="fa-floppy-save"></span>
												<span>fa-floppy-save</span>
											</li>
									
											<li>
												<span class="fa-floppy-open"></span>
												<span>fa-floppy-open</span>
											</li>
									
											<li>
												<span class="fa-credit-card"></span>
												<span>fa-credit-card</span>
											</li>
									
											<li>
												<span class="fa-transfer"></span>
												<span>fa-transfer</span>
											</li>
									
											<li>
												<span class="fa-cutlery"></span>
												<span>fa-cutlery</span>
											</li>
									
											<li>
												<span class="fa-header"></span>
												<span>fa-header</span>
											</li>
									
											<li>
												<span class="fa-compressed"></span>
												<span>fa-compressed</span>
											</li>
									
											<li>
												<span class="fa-earphone"></span>
												<span>fa-earphone</span>
											</li>
									
											<li>
												<span class="fa-phone-alt"></span>
												<span>fa-phone-alt</span>
											</li>
									
											<li>
												<span class="fa-tower"></span>
												<span>fa-tower</span>
											</li>
									
											<li>
												<span class="fa-stats"></span>
												<span>fa-stats</span>
											</li>
									
											<li>
												<span class="fa-sd-video"></span>
												<span>fa-sd-video</span>
											</li>
									
											<li>
												<span class="fa-hd-video"></span>
												<span>fa-hd-video</span>
											</li>
									
											<li>
												<span class="fa-subtitles"></span>
												<span>fa-subtitles</span>
											</li>
									
											<li>
												<span class="fa-sound-stereo"></span>
												<span>fa-sound-stereo</span>
											</li>
									
											<li>
												<span class="fa-sound-dolby"></span>
												<span>fa-sound-dolby</span>
											</li>
									
											<li>
												<span class="fa-sound-5-1"></span>
												<span>fa-sound-5-1</span>
											</li>
									
											<li>
												<span class="fa-sound-6-1"></span>
												<span>fa-sound-6-1</span>
											</li>
									
											<li>
												<span class="fa-sound-7-1"></span>
												<span>fa-sound-7-1</span>
											</li>
									
											<li>
												<span class="fa-copyright-mark"></span>
												<span>fa-copyright-mark</span>
											</li>
									
											<li>
												<span class="fa-registration-mark"></span>
												<span>fa-registration-mark</span>
											</li>
									
											<li>
												<span class="fa-cloud-download"></span>
												<span>fa-cloud-download</span>
											</li>
									
											<li>
												<span class="fa-cloud-upload"></span>
												<span>fa-cloud-upload</span>
											</li>
									
											<li>
												<span class="fa-tree-conifer"></span>
												<span>fa-tree-conifer</span>
											</li>
									
											<li>
												<span class="fa-tree-deciduous"></span>
												<span>fa-tree-deciduous</span>
											</li>
									
											<li>
												<span class="fa-cd"></span>
												<span>fa-cd</span>
											</li>
									
											<li>
												<span class="fa-save-file"></span>
												<span>fa-save-file</span>
											</li>
									
											<li>
												<span class="fa-open-file"></span>
												<span>fa-open-file</span>
											</li>
									
											<li>
												<span class="fa-level-up"></span>
												<span>fa-level-up</span>
											</li>
									
											<li>
												<span class="fa-copy"></span>
												<span>fa-copy</span>
											</li>
									
											<li>
												<span class="fa-paste"></span>
												<span>fa-paste</span>
											</li>
									
											<li>
												<span class="fa-alert"></span>
												<span>fa-alert</span>
											</li>
									
											<li>
												<span class="fa-equalizer"></span>
												<span>fa-equalizer</span>
											</li>
									
											<li>
												<span class="fa-king"></span>
												<span>fa-king</span>
											</li>
									
											<li>
												<span class="fa-queen"></span>
												<span>fa-queen</span>
											</li>
									
											<li>
												<span class="fa-pawn"></span>
												<span>fa-pawn</span>
											</li>
									
											<li>
												<span class="fa-bishop"></span>
												<span>fa-bishop</span>
											</li>
									
											<li>
												<span class="fa-knight"></span>
												<span>fa-knight</span>
											</li>
									
											<li>
												<span class="fa-baby-formula"></span>
												<span>fa-baby-formula</span>
											</li>
									
											<li>
												<span class="fa-tent"></span>
												<span>fa-tent</span>
											</li>
									
											<li>
												<span class="fa-blackboard"></span>
												<span>fa-blackboard</span>
											</li>
									
											<li>
												<span class="fa-bed"></span>
												<span>fa-bed</span>
											</li>
									
											<li>
												<span class="fa-apple"></span>
												<span>fa-apple</span>
											</li>
									
											<li>
												<span class="fa-erase"></span>
												<span>fa-erase</span>
											</li>
									
											<li>
												<span class="fa-hourglass"></span>
												<span>fa-hourglass</span>
											</li>
									
											<li>
												<span class="fa-lamp"></span>
												<span>fa-lamp</span>
											</li>
									
											<li>
												<span class="fa-duplicate"></span>
												<span>fa-duplicate</span>
											</li>
									
											<li>
												<span class="fa-piggy-bank"></span>
												<span>fa-piggy-bank</span>
											</li>
									
											<li>
												<span class="fa-scissors"></span>
												<span>fa-scissors</span>
											</li>
									
											<li>
												<span class="fa-bitcoin"></span>
												<span>fa-bitcoin</span>
											</li>
									
											<li>
												<span class="fa-btc"></span>
												<span>fa-btc</span>
											</li>
									
											<li>
												<span class="fa-xbt"></span>
												<span>fa-xbt</span>
											</li>
									
											<li>
												<span class="fa-yen"></span>
												<span>fa-yen</span>
											</li>
									
											<li>
												<span class="fa-jpy"></span>
												<span>fa-jpy</span>
											</li>
									
											<li>
												<span class="fa-ruble"></span>
												<span>fa-ruble</span>
											</li>
									
											<li>
												<span class="fa-rub"></span>
												<span>fa-rub</span>
											</li>
									
											<li>
												<span class="fa-scale"></span>
												<span>fa-scale</span>
											</li>
									
											<li>
												<span class="fa-ice-lolly"></span>
												<span>fa-ice-lolly</span>
											</li>
									
											<li>
												<span class="fa-ice-lolly-tasted"></span>
												<span>fa-ice-lolly-tasted</span>
											</li>
									
											<li>
												<span class="fa-education"></span>
												<span>fa-education</span>
											</li>
									
											<li>
												<span class="fa-option-horizontal"></span>
												<span>fa-option-horizontal</span>
											</li>
									
											<li>
												<span class="fa-option-vertical"></span>
												<span>fa-option-vertical</span>
											</li>
									
											<li>
												<span class="fa-menu-hamburger"></span>
												<span>fa-menu-hamburger</span>
											</li>
									
											<li>
												<span class="fa-modal-window"></span>
												<span>fa-modal-window</span>
											</li>
									
											<li>
												<span class="fa-oil"></span>
												<span>fa-oil</span>
											</li>
									
											<li>
												<span class="fa-grain"></span>
												<span>fa-grain</span>
											</li>
									
											<li>
												<span class="fa-sunglasses"></span>
												<span>fa-sunglasses</span>
											</li>
									
											<li>
												<span class="fa-text-size"></span>
												<span>fa-text-size</span>
											</li>
									
											<li>
												<span class="fa-text-color"></span>
												<span>fa-text-color</span>
											</li>
									
											<li>
												<span class="fa-text-background"></span>
												<span>fa-text-background</span>
											</li>
									
											<li>
												<span class="fa-object-align-top"></span>
												<span>fa-object-align-top</span>
											</li>
									
											<li>
												<span class="fa-object-align-bottom"></span>
												<span>fa-object-align-bottom</span>
											</li>
									
											<li>
												<span class="fa-object-align-horizontal"></span>
												<span>fa-object-align-horizontal</span>
											</li>
									
											<li>
												<span class="fa-object-align-left"></span>
												<span>fa-object-align-left</span>
											</li>
									
											<li>
												<span class="fa-object-align-vertical"></span>
												<span>fa-object-align-vertical</span>
											</li>
									
											<li>
												<span class="fa-object-align-right"></span>
												<span>fa-object-align-right</span>
											</li>
									
											<li>
												<span class="fa-triangle-right"></span>
												<span>fa-triangle-right</span>
											</li>
									
											<li>
												<span class="fa-triangle-left"></span>
												<span>fa-triangle-left</span>
											</li>
									
											<li>
												<span class="fa-triangle-bottom"></span>
												<span>fa-triangle-bottom</span>
											</li>
									
											<li>
												<span class="fa-triangle-top"></span>
												<span>fa-triangle-top</span>
											</li>
									
											<li>
												<span class="fa-console"></span>
												<span>fa-console</span>
											</li>
									
											<li>
												<span class="fa-superscript"></span>
												<span>fa-superscript</span>
											</li>
									
											<li>
												<span class="fa-subscript"></span>
												<span>fa-subscript</span>
											</li>
									
											<li>
												<span class="fa-menu-left"></span>
												<span>fa-menu-left</span>
											</li>
									
											<li>
												<span class="fa-menu-right"></span>
												<span>fa-menu-right</span>
											</li>
									
											<li>
												<span class="fa-menu-down"></span>
												<span>fa-menu-down</span>
											</li>
									
											<li>
												<span class="fa-menu-up"></span>
												<span>fa-menu-up</span>
											</li>
										</ul>
									</div>
									
								</div>
							</mm_card>
						</mm_col>
						<mm_col class="col-md-6">
							<mm_card>
								<div class="card_head">字体图标（镂空）</div>
								<div class="card_body">
									<mm_icon src="<i class='fa fa-user stroke'></i>"></mm_icon>
									<div class="icons">
									    <ul>
									        <li>
									          <span class="stroke fa-asterisk"></span>
									          <span>stroke fa-asterisk</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-plus"></span>
									          <span>stroke fa-plus</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-euro"></span>
									          <span>stroke fa-euro</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-eur"></span>
									          <span>stroke fa-eur</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-minus"></span>
									          <span>stroke fa-minus</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-cloud"></span>
									          <span>stroke fa-cloud</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-envelope"></span>
									          <span>stroke fa-envelope</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-pencil"></span>
									          <span>stroke fa-pencil</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-glass"></span>
									          <span>stroke fa-glass</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-music"></span>
									          <span>stroke fa-music</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-search"></span>
									          <span>stroke fa-search</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-heart"></span>
									          <span>stroke fa-heart</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-star"></span>
									          <span>stroke fa-star</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-star-empty"></span>
									          <span>stroke fa-star-empty</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-user"></span>
									          <span>stroke fa-user</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-film"></span>
									          <span>stroke fa-film</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-th-large"></span>
									          <span>stroke fa-th-large</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-th"></span>
									          <span>stroke fa-th</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-th-list"></span>
									          <span>stroke fa-th-list</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-ok"></span>
									          <span>stroke fa-ok</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-remove"></span>
									          <span>stroke fa-remove</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-zoom-in"></span>
									          <span>stroke fa-zoom-in</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-zoom-out"></span>
									          <span>stroke fa-zoom-out</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-off"></span>
									          <span>stroke fa-off</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-signal"></span>
									          <span>stroke fa-signal</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-cog"></span>
									          <span>stroke fa-cog</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-trash"></span>
									          <span>stroke fa-trash</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-home"></span>
									          <span>stroke fa-home</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-file"></span>
									          <span>stroke fa-file</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-time"></span>
									          <span>stroke fa-time</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-road"></span>
									          <span>stroke fa-road</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-download-alt"></span>
									          <span>stroke fa-download-alt</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-download"></span>
									          <span>stroke fa-download</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-upload"></span>
									          <span>stroke fa-upload</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-inbox"></span>
									          <span>stroke fa-inbox</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-play-circle"></span>
									          <span>stroke fa-play-circle</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-repeat"></span>
									          <span>stroke fa-repeat</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-refresh"></span>
									          <span>stroke fa-refresh</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-list-alt"></span>
									          <span>stroke fa-list-alt</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-lock"></span>
									          <span>stroke fa-lock</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-flag"></span>
									          <span>stroke fa-flag</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-headphones"></span>
									          <span>stroke fa-headphones</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-volume-off"></span>
									          <span>stroke fa-volume-off</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-volume-down"></span>
									          <span>stroke fa-volume-down</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-volume-up"></span>
									          <span>stroke fa-volume-up</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-qrcode"></span>
									          <span>stroke fa-qrcode</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-barcode"></span>
									          <span>stroke fa-barcode</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-tag"></span>
									          <span>stroke fa-tag</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-tags"></span>
									          <span>stroke fa-tags</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-book"></span>
									          <span>stroke fa-book</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-bookmark"></span>
									          <span>stroke fa-bookmark</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-print"></span>
									          <span>stroke fa-print</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-camera"></span>
									          <span>stroke fa-camera</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-font"></span>
									          <span>stroke fa-font</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-bold"></span>
									          <span>stroke fa-bold</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-italic"></span>
									          <span>stroke fa-italic</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-text-height"></span>
									          <span>stroke fa-text-height</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-text-width"></span>
									          <span>stroke fa-text-width</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-align-left"></span>
									          <span>stroke fa-align-left</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-align-center"></span>
									          <span>stroke fa-align-center</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-align-right"></span>
									          <span>stroke fa-align-right</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-align-justify"></span>
									          <span>stroke fa-align-justify</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-list"></span>
									          <span>stroke fa-list</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-indent-left"></span>
									          <span>stroke fa-indent-left</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-indent-right"></span>
									          <span>stroke fa-indent-right</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-facetime-video"></span>
									          <span>stroke fa-facetime-video</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-picture"></span>
									          <span>stroke fa-picture</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-map-marker"></span>
									          <span>stroke fa-map-marker</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-adjust"></span>
									          <span>stroke fa-adjust</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-tint"></span>
									          <span>stroke fa-tint</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-edit"></span>
									          <span>stroke fa-edit</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-share"></span>
									          <span>stroke fa-share</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-check"></span>
									          <span>stroke fa-check</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-move"></span>
									          <span>stroke fa-move</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-step-backward"></span>
									          <span>stroke fa-step-backward</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-fast-backward"></span>
									          <span>stroke fa-fast-backward</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-backward"></span>
									          <span>stroke fa-backward</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-play"></span>
									          <span>stroke fa-play</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-pause"></span>
									          <span>stroke fa-pause</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-stop"></span>
									          <span>stroke fa-stop</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-forward"></span>
									          <span>stroke fa-forward</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-fast-forward"></span>
									          <span>stroke fa-fast-forward</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-step-forward"></span>
									          <span>stroke fa-step-forward</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-eject"></span>
									          <span>stroke fa-eject</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-chevron-left"></span>
									          <span>stroke fa-chevron-left</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-chevron-right"></span>
									          <span>stroke fa-chevron-right</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-plus-sign"></span>
									          <span>stroke fa-plus-sign</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-minus-sign"></span>
									          <span>stroke fa-minus-sign</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-remove-sign"></span>
									          <span>stroke fa-remove-sign</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-ok-sign"></span>
									          <span>stroke fa-ok-sign</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-question-sign"></span>
									          <span>stroke fa-question-sign</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-info-sign"></span>
									          <span>stroke fa-info-sign</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-screenshot"></span>
									          <span>stroke fa-screenshot</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-remove-circle"></span>
									          <span>stroke fa-remove-circle</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-ok-circle"></span>
									          <span>stroke fa-ok-circle</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-ban-circle"></span>
									          <span>stroke fa-ban-circle</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-arrow-left"></span>
									          <span>stroke fa-arrow-left</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-arrow-right"></span>
									          <span>stroke fa-arrow-right</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-arrow-up"></span>
									          <span>stroke fa-arrow-up</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-arrow-down"></span>
									          <span>stroke fa-arrow-down</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-share-alt"></span>
									          <span>stroke fa-share-alt</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-resize-full"></span>
									          <span>stroke fa-resize-full</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-resize-small"></span>
									          <span>stroke fa-resize-small</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-exclamation-sign"></span>
									          <span>stroke fa-exclamation-sign</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-gift"></span>
									          <span>stroke fa-gift</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-leaf"></span>
									          <span>stroke fa-leaf</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-fire"></span>
									          <span>stroke fa-fire</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-eye-open"></span>
									          <span>stroke fa-eye-open</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-eye-close"></span>
									          <span>stroke fa-eye-close</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-warning-sign"></span>
									          <span>stroke fa-warning-sign</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-plane"></span>
									          <span>stroke fa-plane</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-calendar"></span>
									          <span>stroke fa-calendar</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-random"></span>
									          <span>stroke fa-random</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-comment"></span>
									          <span>stroke fa-comment</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-magnet"></span>
									          <span>stroke fa-magnet</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-chevron-up"></span>
									          <span>stroke fa-chevron-up</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-chevron-down"></span>
									          <span>stroke fa-chevron-down</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-retweet"></span>
									          <span>stroke fa-retweet</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-shopping-cart"></span>
									          <span>stroke fa-shopping-cart</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-folder-close"></span>
									          <span>stroke fa-folder-close</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-folder-open"></span>
									          <span>stroke fa-folder-open</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-resize-vertical"></span>
									          <span>stroke fa-resize-vertical</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-resize-horizontal"></span>
									          <span>stroke fa-resize-horizontal</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-hdd"></span>
									          <span>stroke fa-hdd</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-bullhorn"></span>
									          <span>stroke fa-bullhorn</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-bell"></span>
									          <span>stroke fa-bell</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-certificate"></span>
									          <span>stroke fa-certificate</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-thumbs-up"></span>
									          <span>stroke fa-thumbs-up</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-thumbs-down"></span>
									          <span>stroke fa-thumbs-down</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-hand-right"></span>
									          <span>stroke fa-hand-right</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-hand-left"></span>
									          <span>stroke fa-hand-left</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-hand-up"></span>
									          <span>stroke fa-hand-up</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-hand-down"></span>
									          <span>stroke fa-hand-down</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-circle-arrow-right"></span>
									          <span>stroke fa-circle-arrow-right</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-circle-arrow-left"></span>
									          <span>stroke fa-circle-arrow-left</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-circle-arrow-up"></span>
									          <span>stroke fa-circle-arrow-up</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-circle-arrow-down"></span>
									          <span>stroke fa-circle-arrow-down</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-globe"></span>
									          <span>stroke fa-globe</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-wrench"></span>
									          <span>stroke fa-wrench</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-tasks"></span>
									          <span>stroke fa-tasks</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-filter"></span>
									          <span>stroke fa-filter</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-briefcase"></span>
									          <span>stroke fa-briefcase</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-fullscreen"></span>
									          <span>stroke fa-fullscreen</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-dashboard"></span>
									          <span>stroke fa-dashboard</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-paperclip"></span>
									          <span>stroke fa-paperclip</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-heart-empty"></span>
									          <span>stroke fa-heart-empty</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-link"></span>
									          <span>stroke fa-link</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-phone"></span>
									          <span>stroke fa-phone</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-pushpin"></span>
									          <span>stroke fa-pushpin</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-usd"></span>
									          <span>stroke fa-usd</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-gbp"></span>
									          <span>stroke fa-gbp</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sort"></span>
									          <span>stroke fa-sort</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sort-by-alphabet"></span>
									          <span>stroke fa-sort-by-alphabet</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sort-by-alphabet-alt"></span>
									          <span>stroke fa-sort-by-alphabet-alt</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sort-by-order"></span>
									          <span>stroke fa-sort-by-order</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sort-by-order-alt"></span>
									          <span>stroke fa-sort-by-order-alt</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sort-by-attributes"></span>
									          <span>stroke fa-sort-by-attributes</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sort-by-attributes-alt"></span>
									          <span>stroke fa-sort-by-attributes-alt</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-unchecked"></span>
									          <span>stroke fa-unchecked</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-expand"></span>
									          <span>stroke fa-expand</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-collapse-down"></span>
									          <span>stroke fa-collapse-down</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-collapse-up"></span>
									          <span>stroke fa-collapse-up</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-log-in"></span>
									          <span>stroke fa-log-in</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-flash"></span>
									          <span>stroke fa-flash</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-log-out"></span>
									          <span>stroke fa-log-out</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-new-window"></span>
									          <span>stroke fa-new-window</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-record"></span>
									          <span>stroke fa-record</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-save"></span>
									          <span>stroke fa-save</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-open"></span>
									          <span>stroke fa-open</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-saved"></span>
									          <span>stroke fa-saved</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-import"></span>
									          <span>stroke fa-import</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-export"></span>
									          <span>stroke fa-export</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-send"></span>
									          <span>stroke fa-send</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-floppy-disk"></span>
									          <span>stroke fa-floppy-disk</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-floppy-saved"></span>
									          <span>stroke fa-floppy-saved</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-floppy-remove"></span>
									          <span>stroke fa-floppy-remove</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-floppy-save"></span>
									          <span>stroke fa-floppy-save</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-floppy-open"></span>
									          <span>stroke fa-floppy-open</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-credit-card"></span>
									          <span>stroke fa-credit-card</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-transfer"></span>
									          <span>stroke fa-transfer</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-cutlery"></span>
									          <span>stroke fa-cutlery</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-header"></span>
									          <span>stroke fa-header</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-compressed"></span>
									          <span>stroke fa-compressed</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-earphone"></span>
									          <span>stroke fa-earphone</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-phone-alt"></span>
									          <span>stroke fa-phone-alt</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-tower"></span>
									          <span>stroke fa-tower</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-stats"></span>
									          <span>stroke fa-stats</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sd-video"></span>
									          <span>stroke fa-sd-video</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-hd-video"></span>
									          <span>stroke fa-hd-video</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-subtitles"></span>
									          <span>stroke fa-subtitles</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sound-stereo"></span>
									          <span>stroke fa-sound-stereo</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sound-dolby"></span>
									          <span>stroke fa-sound-dolby</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sound-5-1"></span>
									          <span>stroke fa-sound-5-1</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sound-6-1"></span>
									          <span>stroke fa-sound-6-1</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sound-7-1"></span>
									          <span>stroke fa-sound-7-1</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-copyright-mark"></span>
									          <span>stroke fa-copyright-mark</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-registration-mark"></span>
									          <span>stroke fa-registration-mark</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-cloud-download"></span>
									          <span>stroke fa-cloud-download</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-cloud-upload"></span>
									          <span>stroke fa-cloud-upload</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-tree-conifer"></span>
									          <span>stroke fa-tree-conifer</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-tree-deciduous"></span>
									          <span>stroke fa-tree-deciduous</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-cd"></span>
									          <span>stroke fa-cd</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-save-file"></span>
									          <span>stroke fa-save-file</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-open-file"></span>
									          <span>stroke fa-open-file</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-level-up"></span>
									          <span>stroke fa-level-up</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-copy"></span>
									          <span>stroke fa-copy</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-paste"></span>
									          <span>stroke fa-paste</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-alert"></span>
									          <span>stroke fa-alert</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-equalizer"></span>
									          <span>stroke fa-equalizer</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-king"></span>
									          <span>stroke fa-king</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-queen"></span>
									          <span>stroke fa-queen</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-pawn"></span>
									          <span>stroke fa-pawn</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-bishop"></span>
									          <span>stroke fa-bishop</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-knight"></span>
									          <span>stroke fa-knight</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-baby-formula"></span>
									          <span>stroke fa-baby-formula</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-tent"></span>
									          <span>stroke fa-tent</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-blackboard"></span>
									          <span>stroke fa-blackboard</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-bed"></span>
									          <span>stroke fa-bed</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-apple"></span>
									          <span>stroke fa-apple</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-erase"></span>
									          <span>stroke fa-erase</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-hourglass"></span>
									          <span>stroke fa-hourglass</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-lamp"></span>
									          <span>stroke fa-lamp</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-duplicate"></span>
									          <span>stroke fa-duplicate</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-piggy-bank"></span>
									          <span>stroke fa-piggy-bank</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-scissors"></span>
									          <span>stroke fa-scissors</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-bitcoin"></span>
									          <span>stroke fa-bitcoin</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-btc"></span>
									          <span>stroke fa-btc</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-xbt"></span>
									          <span>stroke fa-xbt</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-yen"></span>
									          <span>stroke fa-yen</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-jpy"></span>
									          <span>stroke fa-jpy</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-ruble"></span>
									          <span>stroke fa-ruble</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-rub"></span>
									          <span>stroke fa-rub</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-scale"></span>
									          <span>stroke fa-scale</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-ice-lolly"></span>
									          <span>stroke fa-ice-lolly</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-ice-lolly-tasted"></span>
									          <span>stroke fa-ice-lolly-tasted</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-education"></span>
									          <span>stroke fa-education</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-option-horizontal"></span>
									          <span>stroke fa-option-horizontal</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-option-vertical"></span>
									          <span>stroke fa-option-vertical</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-menu-hamburger"></span>
									          <span>stroke fa-menu-hamburger</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-modal-window"></span>
									          <span>stroke fa-modal-window</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-oil"></span>
									          <span>stroke fa-oil</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-grain"></span>
									          <span>stroke fa-grain</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-sunglasses"></span>
									          <span>stroke fa-sunglasses</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-text-size"></span>
									          <span>stroke fa-text-size</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-text-color"></span>
									          <span>stroke fa-text-color</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-text-background"></span>
									          <span>stroke fa-text-background</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-object-align-top"></span>
									          <span>stroke fa-object-align-top</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-object-align-bottom"></span>
									          <span>stroke fa-object-align-bottom</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-object-align-horizontal"></span>
									          <span>stroke fa-object-align-horizontal</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-object-align-left"></span>
									          <span>stroke fa-object-align-left</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-object-align-vertical"></span>
									          <span>stroke fa-object-align-vertical</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-object-align-right"></span>
									          <span>stroke fa-object-align-right</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-triangle-right"></span>
									          <span>stroke fa-triangle-right</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-triangle-left"></span>
									          <span>stroke fa-triangle-left</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-triangle-bottom"></span>
									          <span>stroke fa-triangle-bottom</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-triangle-top"></span>
									          <span>stroke fa-triangle-top</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-console"></span>
									          <span>stroke fa-console</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-superscript"></span>
									          <span>stroke fa-superscript</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-subscript"></span>
									          <span>stroke fa-subscript</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-menu-left"></span>
									          <span>stroke fa-menu-left</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-menu-right"></span>
									          <span>stroke fa-menu-right</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-menu-down"></span>
									          <span>stroke fa-menu-down</span>
									        </li>
									      
									        <li>
									          <span class="stroke fa-menu-up"></span>
									          <span>stroke fa-menu-up</span>
									        </li>
									    </ul>
									  </div>
								</div>
							</mm_card>
						</mm_col>
						<mm_col class="col-12 col-md-33">
							<mm_card>
								<div class="card_head">图片图标</div>
								<div class="card_body">
									<mm_icon src="/img/logo.png" class="size-huge"></mm_icon>
									<mm_icon src="/img/logo.png" class="size-larger"></mm_icon>
									<mm_icon src="/img/logo.png" class="size-base"></mm_icon>
									<mm_icon src="/img/logo.png" class="size-small"></mm_icon>
									<mm_icon src="/img/logo.png" class="size-mini"></mm_icon>
								</div>
							</mm_card>
						</mm_col>
					</mm_row>
				</mm_container>
			</mm_warp>
		</main>
	</mm_page>
</template>

<script>
</script>

<style>
	#page_icon .mm_icon {
		font-size: 4rem;
	}
	#page_icon ul {
		list-style: none;
		padding: 0;
	}
	#page_icon li {
		float: left;
		width: 50%;
		padding: 0.5rem 1rem;
	}
	#page_icon .card_body {
		padding: 1rem;
	}
</style>
