# mm_nuxt
 这是超级美眉nuxt.js的vue框架，用于构建vue项目
