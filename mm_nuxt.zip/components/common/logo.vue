<template>
  <div class="logo">
    <img src="/img/logo.png" alt=""><span>长盛系统</span>
  </div>
</template>

<style>
</style>
