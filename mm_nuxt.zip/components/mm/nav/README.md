#栏目类组件

nav_bottom 底部导航

nav_main 主导航

nav_path 路径导航

nav_quick 快捷导航

nav_side 侧边导航

nav_top 顶部导航

nav_user 用户导航
