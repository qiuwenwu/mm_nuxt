#栏目类组件

bar_action 操作栏

bar_ad 广告栏

bar_buy 购物栏

bar_chat 聊天输入栏

bar_count 结算栏

bar_filter 筛选栏

bar_menu 菜单栏

bar_search 搜索栏

bar_sort 排序栏

bar_tab 标签栏

bar_title 标题栏

bar_tool 工具栏

bar_user 用户栏
