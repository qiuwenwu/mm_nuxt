<template>
	<div class="mm_main">
		<slot></slot>
	</div>
</template>

<script>
	export default {};
</script>

<style>
</style>
