<template>
	<div class="mm_body"><slot></slot></div>
</template>

<script>
	export default {
		
	};
</script>

<style>
</style>
