<template>
	<div class="mm_container">
		<slot></slot>
	</div>
</template>

<script>
	export default {};
</script>

<style>
</style>
