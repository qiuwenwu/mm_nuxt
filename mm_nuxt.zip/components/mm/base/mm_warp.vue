<template>
	<div class="mm_warp">
		<slot></slot>
	</div>
</template>

<script>
	export default {};
</script>

<style>
</style>
