<template>
	<form class="mm_form">
		<slot></slot>
	</form>
</template>

<script>
	export default {
		props: {}
	};
</script>

<style>
</style>
