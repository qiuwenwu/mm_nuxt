<template>
	<div class="mm_content">
		<slot></slot>
	</div>
</template>

<script>
	export default {
		props: {}
	};
</script>

<style>
</style>
