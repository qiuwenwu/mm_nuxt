<template>
	<div class="mm_group">
		<slot></slot>
	</div>
</template>

<script>
	export default {};
</script>

<style>
</style>
