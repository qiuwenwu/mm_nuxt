<template>
	<!-- 注册表单 -->
	<div class="form_register">
		
	</div>
</template>

<script>
</script>

<style>
</style>
