<template>
	<!-- 忘记密码表单 -->
	<div class="form_forgot">
		
	</div>
</template>

<script>
</script>

<style>
</style>
