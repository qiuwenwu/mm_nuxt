#表单组件

form_forgot 找回密码

form_login 登录

form_password 修改密码

form_register 注册