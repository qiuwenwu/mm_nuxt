#图表类组件

chart_bar 条形图

chart_depth 深度图

chart_k K线图

chart_line 折线图

chart_panel 仪表盘

chart_pie 饼形图
