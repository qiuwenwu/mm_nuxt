<template>
	<div class="chart_k">
		
	</div>
</template>

<script>
	import mixin from '@/mixins/component.js'
	export default {
		mixins: [mixin],
		props: {

		},
		data() {
			return {};
		}
	}
</script>

<style>
</style>
