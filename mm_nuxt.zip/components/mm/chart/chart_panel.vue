<template>
	<div class="chart_panel">
		
	</div>
</template>

<script>
	import mixin from '@/mixins/component.js'
	export default {
		mixins: [mixin],
		props: {

		},
		data() {
			return {};
		}
	}
</script>

<style>
</style>
