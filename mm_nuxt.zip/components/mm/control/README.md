#控件
control_date 日期选择器

control_file 文件上传控件

control_rich 富文本编辑器
