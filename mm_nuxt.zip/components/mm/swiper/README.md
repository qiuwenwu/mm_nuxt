#轮播组件

swiper_card 卡片轮播

swiper_image 图片轮播

swiper_menu 菜单轮播

swiper_page 页面轮播

swiper_text 文字轮播