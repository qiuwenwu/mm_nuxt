<template>
  <div class="modal_update">升级</div>
</template>

<script>
</script>

<style>
</style>
