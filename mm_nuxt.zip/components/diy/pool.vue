<template>
  <div class="modal_pool">矿池</div>
</template>

<script>
</script>

<style>
</style>
