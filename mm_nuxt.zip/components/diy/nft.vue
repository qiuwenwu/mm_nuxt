<template>
  <div class="modal_nft">
    NFT
  </div>
</template>

<script>
</script>

<style>
</style>
