<template>
  <div class="modal_invite">邀请</div>
</template>

<script>
</script>

<style>
</style>
