<template>
  <div class="update_compose">合成</div>
</template>

<script>
</script>

<style>
</style>
