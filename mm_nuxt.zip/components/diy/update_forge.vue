<template>
  <div class="update_forge">锻造</div>
</template>

<script>
</script>

<style>
</style>
