// Exports the "contextmenu" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/contextmenu')
//   ES2015:
//     import 'tinymce/plugins/contextmenu'
require('./plugin.js');