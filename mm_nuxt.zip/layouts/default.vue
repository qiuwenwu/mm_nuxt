<template>
  <div class="app" id="app">
    <Nuxt />
  </div>
</template>


<script>
  export default {
    data() {
      return {}
    },
    methods: {},
    created() {}
  }
</script>


<style>
</style>
